class AddressModel {
  final String? cep;
  final String? logradouro;
  final String? numero;
  final String? complemento;
  final String? bairro;
  final String? nomeCidade;
  final String? ufCidade;
  final String? zona; // 'Urbana' ou 'Rural'
  final bool temLocalizacaoDiferenciada;
  final String?
  localizacaoDiferenciada; // 'Área de assentamento', 'Terra indígena', 'Área quilombola'

  const AddressModel({
    this.cep,
    this.logradouro,
    this.numero,
    this.complemento,
    this.bairro,
    this.nomeCidade,
    this.ufCidade,
    this.zona,
    this.temLocalizacaoDiferenciada = false,
    this.localizacaoDiferenciada,
  });

  AddressModel copyWith({
    String? cep,
    String? logradouro,
    String? numero,
    String? complemento,
    String? bairro,
    String? nomeCidade,
    String? ufCidade,
    String? zona,
    bool? temLocalizacaoDiferenciada,
    String? localizacaoDiferenciada,
  }) {
    return AddressModel(
      cep: cep ?? this.cep,
      logradouro: logradouro ?? this.logradouro,
      numero: numero ?? this.numero,
      complemento: complemento ?? this.complemento,
      bairro: bairro ?? this.bairro,
      nomeCidade: nomeCidade ?? this.nomeCidade,
      ufCidade: ufCidade ?? this.ufCidade,
      zona: zona ?? this.zona,
      temLocalizacaoDiferenciada:
          temLocalizacaoDiferenciada ?? this.temLocalizacaoDiferenciada,
      localizacaoDiferenciada:
          localizacaoDiferenciada ?? this.localizacaoDiferenciada,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'cep': cep,
      'logradouro': logradouro,
      'numero': numero,
      'complemento': complemento,
      'bairro': bairro,
      'nomeCidade': nomeCidade,
      'ufCidade': ufCidade,
      'zona': zona,
      'temLocalizacaoDiferenciada': temLocalizacaoDiferenciada,
      'localizacaoDiferenciada': localizacaoDiferenciada,
    };
  }

  factory AddressModel.fromJson(Map<String, dynamic> json) {
    bool parseBool(dynamic value) {
      if (value == null) return false;
      if (value is bool) return value;
      if (value is int) return value != 0;
      if (value is String) return value.toLowerCase() == 'true' || value == '1';
      return false;
    }

    return AddressModel(
      cep: json['cep'],
      logradouro: json['logradouro'],
      numero: json['numero'],
      complemento: json['complemento'],
      bairro: json['bairro'],
      nomeCidade: json['nomeCidade'],
      ufCidade: json['ufCidade'],
      zona: json['zona'],
      temLocalizacaoDiferenciada: parseBool(json['temLocalizacaoDiferenciada']),
      localizacaoDiferenciada: json['localizacaoDiferenciada'],
    );
  }
}
